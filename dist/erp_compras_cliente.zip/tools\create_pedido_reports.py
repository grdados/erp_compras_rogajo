﻿from pathlib import Path

base = Path('templates/core/relatorios')

(base / 'pedido_resumo.html').write_text('''{% extends 'core/relatorios/base.html' %}
{% load core_extras %}
{% block title %}Pedido - Resumo{% endblock %}
{% block header_title %}Pedido de Compra (Resumo){% endblock %}
{% block content %}
  <div class="rounded-xl border border-slate-200 bg-white p-5">
    <div class="flex flex-wrap items-start justify-between gap-4">
      <div>
        <div class="ui-title">Pedido: <span class="text-emerald-700">{{ pedido.pedido }}</span></div>
        <div class="mt-1 text-slate-600">Data: {{ pedido.data|date:'d/m/Y' }} | Vencimento: {{ pedido.vencimento|date:'d/m/Y' }}</div>
      </div>
      <div class="text-right">
        <div class="text-slate-500">Total</div>
        <div class="ui-title">R$ {{ pedido.valor_total|decimal_br:2 }}</div>
        <div class="text-slate-600">Saldo a faturar: {{ pedido.saldo_faturar|decimal_br:2 }}</div>
      </div>
    </div>

    <div class="mt-4 grid gap-3 sm:grid-cols-2">
      <div class="rounded-lg bg-slate-50 p-3">
        <div class="text-slate-500">Safra</div>
        <div class="font-bold">{% if pedido.safra %}{{ pedido.safra.safra }}{% else %}-{% endif %}</div>
      </div>
      <div class="rounded-lg bg-slate-50 p-3">
        <div class="text-slate-500">Fornecedor</div>
        <div class="font-bold">{% if pedido.fornecedor %}{{ pedido.fornecedor.fornecedor }}{% else %}-{% endif %}</div>
      </div>
      <div class="rounded-lg bg-slate-50 p-3">
        <div class="text-slate-500">Cliente</div>
        <div class="font-bold">{{ pedido.cliente }}</div>
      </div>
      <div class="rounded-lg bg-slate-50 p-3">
        <div class="text-slate-500">Produtor</div>
        <div class="font-bold">{{ pedido.produtor.produtor }}{% if pedido.produtor.fazenda %} - {{ pedido.produtor.fazenda }}{% endif %}</div>
      </div>
    </div>
  </div>

  <div class="mt-6 rounded-xl border border-slate-200 bg-white">
    <div class="border-b border-slate-200 px-5 py-3">
      <div class="ui-title">Produtos</div>
    </div>
    <div class="overflow-x-auto">
      <table class="w-full whitespace-nowrap text-left">
        <thead>
          <tr class="bg-slate-50 text-slate-700">
            <th class="px-4 py-3 font-bold">Produto</th>
            <th class="px-4 py-3 font-bold">Unidade</th>
            <th class="px-4 py-3 font-bold">Quantidade</th>
            <th class="px-4 py-3 font-bold">Preco</th>
            <th class="px-4 py-3 font-bold">Desconto</th>
            <th class="px-4 py-3 font-bold">Total</th>
          </tr>
        </thead>
        <tbody>
          {% for it in itens %}
            <tr class="border-t border-slate-200">
              <td class="px-4 py-3">{% if it.produto_cadastro %}{{ it.produto_cadastro.nome }}{% else %}{{ it.produto }}{% endif %}</td>
              <td class="px-4 py-3">{{ it.unidade }}</td>
              <td class="px-4 py-3">{{ it.quantidade|decimal_br:3 }}</td>
              <td class="px-4 py-3">{{ it.preco|decimal_br:5 }}</td>
              <td class="px-4 py-3">{{ it.desconto|decimal_br:2 }}</td>
              <td class="px-4 py-3 font-bold">{{ it.total_item|decimal_br:2 }}</td>
            </tr>
          {% empty %}
            <tr><td class="px-4 py-6 text-slate-500" colspan="10">Sem itens.</td></tr>
          {% endfor %}
        </tbody>
      </table>
    </div>
  </div>

  <div class="mt-6 grid gap-6 lg:grid-cols-2">
    <div class="rounded-xl border border-slate-200 bg-white">
      <div class="border-b border-slate-200 px-5 py-3"><div class="ui-title">Notas fiscais (Faturamento)</div></div>
      <div class="overflow-x-auto">
        <table class="w-full whitespace-nowrap text-left">
          <thead><tr class="bg-slate-50 text-slate-700">
            <th class="px-4 py-3 font-bold">Nota</th>
            <th class="px-4 py-3 font-bold">Data</th>
            <th class="px-4 py-3 font-bold">Vencimento</th>
            <th class="px-4 py-3 font-bold">Valor</th>
            <th class="px-4 py-3 font-bold">Status</th>
          </tr></thead>
          <tbody>
            {% for nf in faturamentos %}
              <tr class="border-t border-slate-200">
                <td class="px-4 py-3">{{ nf.nota_fiscal }}</td>
                <td class="px-4 py-3">{{ nf.data|date:'d/m/Y' }}</td>
                <td class="px-4 py-3">{{ nf.vencimento|date:'d/m/Y' }}</td>
                <td class="px-4 py-3">{{ nf.valor_total|decimal_br:2 }}</td>
                <td class="px-4 py-3">{{ nf.get_status_display }}</td>
              </tr>
            {% empty %}
              <tr><td class="px-4 py-6 text-slate-500" colspan="10">Sem notas.</td></tr>
            {% endfor %}
          </tbody>
        </table>
      </div>
    </div>

    <div class="rounded-xl border border-slate-200 bg-white">
      <div class="border-b border-slate-200 px-5 py-3"><div class="ui-title">Faturas (Contas a Pagar)</div></div>
      <div class="overflow-x-auto">
        <table class="w-full whitespace-nowrap text-left">
          <thead><tr class="bg-slate-50 text-slate-700">
            <th class="px-4 py-3 font-bold">Documento</th>
            <th class="px-4 py-3 font-bold">Origem</th>
            <th class="px-4 py-3 font-bold">Vencimento</th>
            <th class="px-4 py-3 font-bold">Valor</th>
            <th class="px-4 py-3 font-bold">Saldo</th>
            <th class="px-4 py-3 font-bold">Status</th>
          </tr></thead>
          <tbody>
            {% for c in contas %}
              <tr class="border-t border-slate-200">
                <td class="px-4 py-3">{{ c.nota_fiscal }}</td>
                <td class="px-4 py-3">{{ c.get_origem_display }}</td>
                <td class="px-4 py-3">{{ c.vencimento|date:'d/m/Y' }}</td>
                <td class="px-4 py-3">{{ c.valor_total|decimal_br:2 }}</td>
                <td class="px-4 py-3">{{ c.saldo_aberto|decimal_br:2 }}</td>
                <td class="px-4 py-3">{{ c.status_label }}</td>
              </tr>
            {% empty %}
              <tr><td class="px-4 py-6 text-slate-500" colspan="10">Sem faturas.</td></tr>
            {% endfor %}
          </tbody>
        </table>
      </div>
    </div>
  </div>
{% endblock %}
''', encoding='utf-8')

(base / 'pedido_analitico.html').write_text('''{% extends 'core/relatorios/base.html' %}
{% load core_extras %}
{% block title %}Pedidos - Analitico{% endblock %}
{% block header_title %}Pedidos de Compra (Analitico){% endblock %}
{% block content %}
  <div class="rounded-xl border border-slate-200 bg-white p-5">
    <div class="ui-title">Analitico</div>
    <div class="mt-1 text-slate-600">Pedidos listados com produtos e notas fiscais vinculadas.</div>
  </div>

  {% for pedido in pedidos %}
    <div class="mt-6 rounded-xl border border-slate-200 bg-white">
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-5 py-3">
        <div>
          <div class="ui-title">Pedido: <span class="text-emerald-700">{{ pedido.pedido }}</span></div>
          <div class="text-slate-600">Data: {{ pedido.data|date:'d/m/Y' }} | Vencimento: {{ pedido.vencimento|date:'d/m/Y' }}</div>
        </div>
        <div class="text-right">
          <div class="text-slate-500">Total</div>
          <div class="ui-title">R$ {{ pedido.valor_total|decimal_br:2 }}</div>
        </div>
      </div>

      <div class="p-5">
        <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div class="rounded-lg bg-slate-50 p-3"><div class="text-slate-500">Safra</div><div class="font-bold">{% if pedido.safra %}{{ pedido.safra.safra }}{% else %}-{% endif %}</div></div>
          <div class="rounded-lg bg-slate-50 p-3"><div class="text-slate-500">Cliente</div><div class="font-bold">{{ pedido.cliente }}</div></div>
          <div class="rounded-lg bg-slate-50 p-3"><div class="text-slate-500">Produtor</div><div class="font-bold">{{ pedido.produtor.produtor }}{% if pedido.produtor.fazenda %} - {{ pedido.produtor.fazenda }}{% endif %}</div></div>
          <div class="rounded-lg bg-slate-50 p-3"><div class="text-slate-500">Fornecedor</div><div class="font-bold">{% if pedido.fornecedor %}{{ pedido.fornecedor.fornecedor }}{% else %}-{% endif %}</div></div>
        </div>

        <div class="mt-4 overflow-x-auto rounded-xl border border-slate-200">
          <table class="w-full whitespace-nowrap text-left">
            <thead>
              <tr class="bg-slate-50 text-slate-700">
                <th class="px-4 py-3 font-bold">Produto</th>
                <th class="px-4 py-3 font-bold">Unidade</th>
                <th class="px-4 py-3 font-bold">Quantidade</th>
                <th class="px-4 py-3 font-bold">Preco</th>
                <th class="px-4 py-3 font-bold">Desconto</th>
                <th class="px-4 py-3 font-bold">Total</th>
              </tr>
            </thead>
            <tbody>
              {% for it in pedido.itens.all %}
                <tr class="border-t border-slate-200">
                  <td class="px-4 py-3">{% if it.produto_cadastro %}{{ it.produto_cadastro.nome }}{% else %}{{ it.produto }}{% endif %}</td>
                  <td class="px-4 py-3">{{ it.unidade }}</td>
                  <td class="px-4 py-3">{{ it.quantidade|decimal_br:3 }}</td>
                  <td class="px-4 py-3">{{ it.preco|decimal_br:5 }}</td>
                  <td class="px-4 py-3">{{ it.desconto|decimal_br:2 }}</td>
                  <td class="px-4 py-3 font-bold">{{ it.total_item|decimal_br:2 }}</td>
                </tr>
              {% empty %}
                <tr><td class="px-4 py-6 text-slate-500" colspan="10">Sem itens.</td></tr>
              {% endfor %}
            </tbody>
          </table>
        </div>

        <div class="mt-4">
          <div class="font-bold text-slate-800">Notas fiscais vinculadas</div>
          <ul class="mt-2 list-disc pl-5 text-slate-700">
            {% for nf in pedido.faturamentos.all %}
              <li>{{ nf.nota_fiscal }} ({{ nf.data|date:'d/m/Y' }}) - R$ {{ nf.valor_total|decimal_br:2 }} - {{ nf.get_status_display }}</li>
            {% empty %}
              <li class="text-slate-500">Sem notas.</li>
            {% endfor %}
          </ul>
        </div>
      </div>
    </div>
  {% empty %}
    <div class="mt-6 rounded-xl border border-slate-200 bg-white p-5 text-slate-500">Sem registros.</div>
  {% endfor %}
{% endblock %}
''', encoding='utf-8')

print('OK: pedido reports templates')
